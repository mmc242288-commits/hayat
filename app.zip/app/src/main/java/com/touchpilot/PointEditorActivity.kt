package com.touchpilot

import android.app.Activity
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.min

class PointEditorActivity : Activity() {
    private lateinit var editor: PointCanvas

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun actionButton(label: String, color: Int, weight: Float, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 15f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(8), dp(14), dp(8), dp(14))
        background = GradientDrawable().apply { setColor(color); cornerRadius = dp(12).toFloat() }
        isClickable = true
        layoutParams = LinearLayout.LayoutParams(0, -2, weight).apply { setMargins(dp(4), 0, dp(4), 0) }
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Brand.INK
        window.navigationBarColor = Brand.INK
        val path = intent.getStringExtra("image_path")
        val bitmap = BitmapFactory.decodeFile(path)
        if (bitmap == null) {
            Toast.makeText(this, "تعذر فتح صورة الشاشة", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        editor = PointCanvas(bitmap)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Brand.INK)
        }
        // Header: title + one-line instruction.
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(10))
            addView(TextView(this@PointEditorActivity).apply {
                text = "حياة · تحديد النقاط"; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
            })
            addView(TextView(this@PointEditorActivity).apply {
                text = "اضغط على الصورة لإضافة نقطة. اسحب النقطة لتحريكها."
                textSize = 12f; setTextColor(Brand.MUTED); setPadding(0, dp(2), 0, 0)
            })
        })
        root.addView(editor, LinearLayout.LayoutParams(-1, 0, 1f))
        // Footer: cancel / undo / save.
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(10), dp(12), dp(12))
            addView(actionButton("إلغاء", 0xFF3A3F4A.toInt(), 1f) { finish() })
            addView(actionButton("تراجع", Brand.TILE, 1f) { editor.undo() })
            addView(actionButton("حفظ النقاط", Brand.GREEN, 1.6f) {
                val array = JSONArray()
                editor.normalizedPoints().forEach { (x, y) ->
                    array.put(JSONObject().put("x", x).put("y", y))
                }
                getSharedPreferences("tp", 0).edit().putString("points", array.toString()).apply()
                startService(Intent(this@PointEditorActivity, TouchService::class.java)
                    .setAction(TouchService.ACTION_REFRESH_POINTS))
                finish()
            })
        })
        setContentView(root)
    }

    override fun onDestroy() {
        startService(Intent(this, TouchService::class.java)
            .setAction(TouchService.ACTION_RESTORE_OVERLAYS))
        super.onDestroy()
    }

    private inner class PointCanvas(private val bitmap: Bitmap) : View(this@PointEditorActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val points = mutableListOf<PointF>()
        private var selected = -1
        private var scale = 1f
        private var left = 0f
        private var top = 0f
        private val radius = dp(16).toFloat()
        // Touch tolerance for grabbing an existing point, in image pixels.
        private val grabRadius get() = dp(26) / scale.coerceAtLeast(0.01f)

        init {
            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
        }

        fun undo() {
            if (points.isNotEmpty()) { points.removeAt(points.lastIndex); invalidate() }
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            scale = min(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
            left = (width - bitmap.width * scale) / 2f
            top = (height - bitmap.height * scale) / 2f
            canvas.drawColor(Color.BLACK)
            canvas.drawBitmap(bitmap, null, RectF(left, top, left + bitmap.width * scale, top + bitmap.height * scale), paint)
            points.forEachIndexed { i, p ->
                val x = left + p.x * scale
                val y = top + p.y * scale
                paint.style = Paint.Style.FILL
                paint.color = 0xE613B27E.toInt()
                canvas.drawCircle(x, y, radius, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = dp(2).toFloat()
                paint.color = Color.WHITE
                canvas.drawCircle(x, y, radius, paint)
                paint.style = Paint.Style.FILL
                paint.color = Color.WHITE
                paint.textSize = dp(14).toFloat()
                paint.typeface = Typeface.DEFAULT_BOLD
                paint.textAlign = Paint.Align.CENTER
                canvas.drawText((i + 1).toString(), x, y + paint.textSize * 0.35f, paint)
            }
        }

        fun normalizedPoints(): List<Pair<Float, Float>> =
            points.map { it.x / bitmap.width.toFloat() to it.y / bitmap.height.toFloat() }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    val imageX = (event.x - left) / scale
                    val imageY = (event.y - top) / scale
                    selected = points.indexOfLast {
                        kotlin.math.hypot(it.x - imageX, it.y - imageY) < grabRadius
                    }
                    if (selected < 0 && imageX in 0f..bitmap.width.toFloat() && imageY in 0f..bitmap.height.toFloat()) {
                        points.add(PointF(imageX, imageY))
                        selected = points.lastIndex
                    }
                    invalidate()
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (selected >= 0) {
                        val x = ((event.x - left) / scale).coerceIn(0f, bitmap.width.toFloat())
                        val y = ((event.y - top) / scale).coerceIn(0f, bitmap.height.toFloat())
                        points[selected].set(x, y)
                        invalidate()
                    }
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { selected = -1; return true }
            }
            return true
        }
    }
}
