package com.touchpilot

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var apps: List<ApplicationInfo>
    private lateinit var spinner: Spinner
    private val captureRequest = 4102
    private val handler = Handler(Looper.getMainLooper())

    // One permission row: a status chip plus an action button that changes with the state.
    private class StatusRow(val chip: TextView, val button: TextView, val isOn: () -> Boolean)
    private val rows = mutableListOf<StatusRow>()

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radiusDp).toFloat()
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun card(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = rounded(Brand.CARD, 18)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
        addView(text(title, 15f, Brand.MINT, true))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Brand.INK
        window.navigationBarColor = Brand.INK

        apps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { it.packageName != packageName && packageManager.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { packageManager.getApplicationLabel(it).toString().lowercase() }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(28), dp(18), dp(28))
        }

        // Header: logo, name, one-line description.
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(HayatLogoView(this@MainActivity, 92))
            addView(text("حياة", 32f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0)
            })
            addView(text("أزرار لمس عائمة تضغط معًا في اللحظة نفسها", 13f, Brand.MUTED).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(2), 0, dp(4))
            })
        })

        // Step 1: pick the app.
        val appCard = card("١  اختر التطبيق")
        val labels = apps.map { packageManager.getApplicationLabel(it).toString() }
        spinner = Spinner(this)
        spinner.adapter = object : ArrayAdapter<String>(this@MainActivity, android.R.layout.simple_spinner_item, labels) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
                (super.getView(position, convertView, parent) as TextView).apply {
                    setTextColor(Color.WHITE); textSize = 15f; setPadding(dp(14), dp(12), dp(14), dp(12))
                }

            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View =
                (super.getDropDownView(position, convertView, parent) as TextView).apply {
                    setTextColor(Color.BLACK); textSize = 15f; setPadding(dp(16), dp(12), dp(16), dp(12))
                }
        }
        spinner.setBackgroundColor(Color.TRANSPARENT)
        val saved = getSharedPreferences("tp", 0).getString("target", null)
        val savedIndex = apps.indexOfFirst { it.packageName == saved }
        if (savedIndex >= 0) spinner.setSelection(savedIndex)
        appCard.addView(FrameLayout(this).apply {
            background = rounded(Brand.TILE, 12)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
            addView(spinner, FrameLayout.LayoutParams(-1, -2))
            addView(text("▾", 16f, Brand.MUTED).apply {
                setPadding(dp(14), 0, dp(14), 0)
            }, FrameLayout.LayoutParams(-2, -2).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL })
        })
        root.addView(appCard)

        // Step 2: permissions with live status.
        val permCard = card("٢  الصلاحيات")
        permissionRow(permCard, 1, "الظهور فوق التطبيقات", "لعرض لوحة حياة وأزرار T فوق التطبيق المختار.",
            { Settings.canDrawOverlays(this) }) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        permissionRow(permCard, 2, "خدمة إمكانية الوصول", "لتنفيذ اللمسات في أماكن الأزرار. فعّل «حياة» من القائمة.",
            { accessibilityOn() }) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        permissionRow(permCard, 3, "التقاط الشاشة", "اختياري: لتحديد النقاط على لقطة من التطبيق.",
            { TouchService.projectionActive }) {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
        }
        root.addView(permCard)

        // Main action.
        root.addView(TextView(this).apply {
            text = "تشغيل حياة وفتح التطبيق"
            textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Brand.GREEN, Brand.TEAL)).apply {
                cornerRadius = dp(16).toFloat()
            }
            isClickable = true
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) }
            setOnClickListener { launchSelected() }
        })

        // How it works.
        val helpCard = card("طريقة الاستخدام")
        listOf(
            "فعّل الصلاحيات في الأعلى.",
            "اختر التطبيق ثم اضغط «تشغيل حياة».",
            "حرّك أزرار T إلى المكان المطلوب، وأضف نسخًا من لوحة حياة العائمة (الشعار الدائري).",
            "اضغط أي T فيضغط هو ونسخه معًا في اللحظة نفسها.",
            "لإخفاء شكل الأزرار من الشاشة اختر «إخفاء الأزرار» من اللوحة، وتبقى الأزرار الصغيرة تحت الشعار."
        ).forEachIndexed { i, line ->
            helpCard.addView(text("${i + 1}.  $line", 13f, Color.WHITE).apply {
                setLineSpacing(0f, 1.15f); setPadding(0, dp(8), 0, 0)
            })
        }
        helpCard.addView(text("لا يضغط شيء من تلقاء نفسه: التنفيذ يحدث فقط عند ضغطك على الزر.", 12f, Brand.MUTED).apply {
            setPadding(0, dp(12), 0, 0)
        })
        root.addView(helpCard)

        root.addView(text("حياة ${versionLabel()}", 11f, Brand.MUTED).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(16), 0, 0)
            layoutParams = LinearLayout.LayoutParams(-1, -2)
        })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Brand.INK)
            isFillViewport = true
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun versionLabel(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: ""
    } catch (_: Exception) { "" }

    private fun accessibilityOn(): Boolean {
        if (TouchAccessibilityService.instance != null) return true
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabled.split(':').any { it.startsWith("$packageName/") }
    }

    private fun permissionRow(parent: LinearLayout, number: Int, title: String, desc: String, isOn: () -> Boolean, onClick: () -> Unit) {
        val badge = TextView(this).apply {
            text = number.toString(); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Brand.TILE) }
            layoutParams = LinearLayout.LayoutParams(dp(28), dp(28))
        }
        val titleView = text(title, 14f, Color.WHITE, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10); marginEnd = dp(10) }
        }
        val chip = TextView(this).apply {
            textSize = 11f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(badge); addView(titleView); addView(chip)
        }
        val descView = text(desc, 12f, Brand.MUTED).apply { setPaddingRelative(dp(38), dp(4), 0, dp(8)) }
        val button = TextView(this).apply {
            textSize = 13f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(dp(14), dp(10), dp(14), dp(10))
            isClickable = true
            setOnClickListener { onClick() }
        }
        parent.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(12), 0, dp(2))
            addView(header); addView(descView); addView(button)
        })
        rows.add(StatusRow(chip, button, isOn))
    }

    private fun refreshStatus() {
        rows.forEach { r ->
            val on = r.isOn()
            r.chip.text = if (on) "مفعّل" else "غير مفعّل"
            r.chip.setTextColor(Brand.INK)
            r.chip.background = rounded(if (on) Brand.MINT else Brand.WARN, 12)
            r.button.text = if (on) "مراجعة الإعداد" else "تفعيل الآن"
            r.button.setTextColor(Color.WHITE)
            r.button.background = rounded(if (on) Brand.TILE else Brand.GREEN, 12)
        }
    }

    private fun launchSelected() {
        val app = apps.getOrNull(spinner.selectedItemPosition) ?: return
        getSharedPreferences("tp", 0).edit().putString("target", app.packageName).apply()
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "امنح صلاحية الظهور فوق التطبيقات أولاً", Toast.LENGTH_LONG).show()
            return
        }
        if (!accessibilityOn()) {
            Toast.makeText(this, "فعّل خدمة إمكانية الوصول لتعمل الأزرار", Toast.LENGTH_LONG).show()
        }
        startService(Intent(this, TouchService::class.java).setAction(TouchService.ACTION_SHOW_PANEL))
        packageManager.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) }
    }

    @Deprecated("Legacy result API retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, TouchService::class.java).apply {
                action = TouchService.ACTION_START_PROJECTION
                putExtra(TouchService.EXTRA_RESULT_CODE, resultCode)
                putExtra(TouchService.EXTRA_RESULT_DATA, data)
            }
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
            Toast.makeText(this, "تم منح إذن التقاط الشاشة", Toast.LENGTH_LONG).show()
            // The service needs a moment to start before the status can show as active.
            handler.postDelayed({ refreshStatus() }, 800L)
        }
    }
}
